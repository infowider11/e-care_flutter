
import 'dart:async';

Map? user_Data;
Timer? globel_timer;
int? unread_noti_count=0;
