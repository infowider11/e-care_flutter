import 'package:flutter/cupertino.dart';


class MyGlobalKeys{
 static final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

 // static final GlobalKey<Provider_home_pageState> providerHomePageKey = GlobalKey<Provider_home_pageState>();
}